def test():
    greet = 'Hello World'
    return greet